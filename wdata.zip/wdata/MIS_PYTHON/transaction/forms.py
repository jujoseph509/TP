from django import forms
from .models import Transaction
from compte.models import Compte

class TransactionForm(forms.ModelForm):
    def __init__(self, user, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['compte'].queryset = Compte.objects.filter(client_id=user.pk)

    class Meta:
        model = Transaction
        fields = '__all__'