from django.contrib import admin
from .models import Transaction

# Register your models here.
@admin.register(Transaction)
class TransactionAdmin(admin.ModelAdmin):   
    list_display = ['compte_client_email', 'type_transac', 'montant_transac', 'date_transac', 'updated_at',] 

    def compte_client_email(self, obj):
        return f" {obj.compte.client} - ({obj.compte.type_compte} - {obj.compte.devise_compte})"

    # def save_model(self, request, obj, form, change) -> None:
    #     if obj.type_transaction == 'depot':
    #         obj.compte.solde += obj.montant
    #     elif obj.type_transaction == 'retrait':
    #         if obj.montant > obj.compte.solde:
    #             self.message_user(request, "Le montant du retrait est superieur au solde disponible.")
    #             return 
    #         obj.compte.solde -= obj.montant

    #     obj.compte.save()
    #     obj.save()
    #     self.message_user(request, "La transaction a ete enregistre avec success.")
    #     # return super().save_model(request, obj, form, change)