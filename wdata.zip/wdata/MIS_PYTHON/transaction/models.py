from django.db import models
from compte.models import Compte
from django.core.exceptions import ValidationError

# Create your models here.

TRANSACTION_CHOICES = (
    ('depot', 'Depot'),
    ('retrait', 'Retrait')
)
class Transaction(models.Model):
    compte = models.ForeignKey(Compte, on_delete=models.CASCADE, related_name='transaction_compte')
    type_transac = models.CharField(max_length=7, choices=TRANSACTION_CHOICES)
    montant_transac = models.DecimalField(max_digits=10, decimal_places=2)
    date_transac = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self) -> str:
        return super().__str__()
    

    def is_montant_negatif(self):
        return self.montant_transac <=0

    def is_dispose_montant(self):
        if self.type_transac == 'retrait':
            return self.montant_transac >= self.compte.solde


    def save(self, *args, **kwargs):
        if self.compte.is_compte_actif():
            if self.type_transac == 'depot':
                self.compte.crediter(self.montant_transac)
            elif self.type_transac == 'retrait' and self.montant_transac <= self.compte.solde:
                self.compte.debiter(self.montant_transac)
        self.compte.save()
        super().save(*args, **kwargs)

    def clean(self):
        if not self.compte.is_compte_actif():
            raise ValidationError("La transaction ne peut pas être effectué car le compte n'est pas actif.")

        if self.compte.is_compte_bloquer():
            raise ValidationError("Le compte est bloquer, vous ne pouvez pas faire de transaction")
            
        if self.is_montant_negatif():
            raise ValidationError({'montant':"Le montant saisi doit être supérieur à zéro. Veuillez entrer une valeur positive."})

        if self.is_dispose_montant():
            raise ValidationError({'montant':"Vous n'avez pas suffisamment d'argent pour retirer cette somme. Veuillez entrer un montant moins élevé."})