from django import forms
from .models import Transfert
from compte.models import Compte

class TransfertForm(forms.ModelForm):
    def __init__(self, user, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['compte_src'].queryset = Compte.objects.filter(client_id=user.pk)
    class Meta:
        model = Transfert
        fields = ("__all__")
        exclude = ("montant_recu", )
