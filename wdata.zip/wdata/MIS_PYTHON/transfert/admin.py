from django.contrib import admin
from .models import Transfert
# Register your models here.
@admin.register(Transfert)
class TransfertAdmin(admin.ModelAdmin):
    list_display = ['compte_src', 'compte_des', 'montant_transfert', 'montant_recu', 'date_transfert']
    # readonly_fields=('montant_recu',) 
    # readonly_fields=('montant_recu',) 

    def compte_src_info(self, obj):
        return f"{obj.compte_src.client} (Devise: {obj.compte_src.devise_compte})"

    def compte_des_info(self, obj):
        return f"{obj.compte_des.client} (Devise: {obj.compte_des.devise_compte})"
