from django.db import models
from django.core.exceptions import ValidationError
from compte.models import Compte
from decimal import Decimal


# Create your models here.
GOURDES = Decimal('1')
DOLLARS = Decimal('150')

class Transfert(models.Model):
    compte_src = models.ForeignKey(Compte, on_delete=models.CASCADE, related_name='transfert_compte_src')
    compte_des = models.ForeignKey(Compte, on_delete=models.CASCADE, related_name='transfert_compte_des')
    montant_transfert = models.DecimalField(max_digits=10, decimal_places=2)
    montant_recu = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    date_transfert = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = ("Transfert")
        verbose_name_plural = ("Transferts")

    def __str__(self):
        return self.compte_src.type_compte
    
    def is_montant_negatif(self):
        return self.montant_transfert <=0 

    def is_same_devise(self):
        return self.compte_src.devise_compte == self.compte_des.devise_compte

    def is_dispose_montant(self):
        """verifier que l'utilisateur possede la somme et plus de celle quelle souhaire retire"""
        return self.montant_transfert <= self.compte_src.solde  

    @property
    def is_des_gourdes(self):
        return self.compte_des.devise_compte == 'gourdes'

    @property
    def is_cs_gourdes(self):
        return self.compte_src.devise_compte == 'gourdes'
    
    def is_comptes_are_actif(self):
        """ verifier que les deux comptes sont actifs"""
        return self.compte_src.is_compte_actif() ==  self.compte_des.is_compte_actif()
    
    def is_transfert_to_different_compte(self):
        """ verifier que le compte source transfert de l'argent a un compte que celui de self(lui)"""
        return self.compte_src != self.compte_des
            
    def clean(self):
        if self.is_montant_negatif():
            raise ValidationError({'montant_emis':"Le montant saisi doit être supérieur à zéro. Veuillez entrer une valeur positive."})

        if not self.is_transfert_to_different_compte():
            raise ValidationError({'compte_src': "Impossible de transférer depuis le compte source actuellement utilisé."})

        if not self.is_dispose_montant(): 
            raise ValidationError({'montant_emis': "Vous n'avez pas suffisamment de fonds pour effectuer ce transfert."}) 


        if self.compte_des.is_compte_bloquer() or self.compte_src.is_compte_bloquer():
            raise ValidationError({'compte_des':"En raison de blocage de compte le transfert ne peux pas effetuer"})
        if not self.is_comptes_are_actif():
            raise ValidationError("Le transfert ne peut pas être effectué l'une des deux compte n'est pas actif.")

            
    def gourde_to_dollar(self, amount):
        return amount / DOLLARS
    
    def dollar_to_gourde(self, amount):
        return amount * DOLLARS

    def conversion(self):
        if self.is_same_devise(): 
            self.montant_recu = self.montant_transfert
        else:
            if self.compte_src.devise_compte == 'gourdes':
                self.montant_recu = self.gourde_to_dollar(self.montant_transfert)
            else:
                self.montant_recu = self.dollar_to_gourde(self.montant_transfert)

        self.compte_src.debiter(self.montant_transfert)
        self.compte_des.crediter(self.montant_recu)

    def save(self, *args, **kwargs):
        if self.is_comptes_are_actif() and self.is_dispose_montant() and self.is_transfert_to_different_compte():
            self.conversion()
            self.compte_src.save()
            self.compte_des.save()
            super().save(*args, **kwargs)
