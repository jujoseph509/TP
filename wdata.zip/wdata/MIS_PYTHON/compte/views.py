from django.shortcuts import render
from django.urls import reverse_lazy

from django.views.generic import TemplateView, CreateView, ListView
from django.contrib.auth.mixins import LoginRequiredMixin

from transaction.models import Transaction
from transaction.forms import TransactionForm

from transfert.models import Transfert
from transfert.forms import TransfertForm

from pret.forms import PretForm


from .models import Compte
from .forms import CompteForm

from client.models import Client
from pret.models import Pret

from remboursement.models import Remboursement
from remboursement.forms import RemboursementForm
from django.contrib.auth.mixins import LoginRequiredMixin

# Create your views here.
class CompteTemplateView(TemplateView):
    template_name = "compte/compte_view.html"

class CompteView(TemplateView):
    template_name = "compte/list/compte.html"

class GestionCompteView(LoginRequiredMixin, ListView):
    template_name = "compte/ges/gestion_compte.html"
    model = Compte

    def get_queryset(self):
        return Compte.objects.filter(client=self.request.user)
    



class TransfertListView( ListView):
    model = Transfert
    template_name = "compte/list/transfert_list.html"

    def get_queryset(self):
        return Transfert.objects.filter(compte_src_id=self.request.user.id)
    

class TransactionListView( ListView):
    model = Transaction
    template_name = "compte/list/transaction_list.html"

    def get_queryset(self):
        return Transaction.objects.filter(compte=self.request.user.id)

class PretListView(LoginRequiredMixin, ListView):
    model = Pret
    template_name = "compte/list/pret_list.html"

    def get_queryset(self):
        return Pret.objects.filter(compte=self.request.user.id)

class RemboursementListView(LoginRequiredMixin, ListView):
    model = Remboursement
    template_name = "compte/list/remboursement_list.html"

    def get_queryset(self):
        return Remboursement.objects.filter(pret__compte=self.request.user.id)



class CompteCreateView(LoginRequiredMixin, CreateView):
    model = Compte
    form_class = CompteForm
    success_url = reverse_lazy('compte_home')
    template_name = "compte/compte_create.html"

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['user'] = self.request.user
        return kwargs

    def form_valid(self, form):
        # form.instance.client = self.request.email
        form.instance.client = self.request.user
        # form.instance.etat_compte = 'actif' # Ajouter une valeur par défaut à "etat_compte"
        return super().form_valid(form)

class TransactionCreateView(LoginRequiredMixin, CreateView):
    model = Transaction
    form_class = TransactionForm
    success_url = reverse_lazy('compte_home')
    template_name = "compte/transaction_create.html"

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['user'] = self.request.user
        return kwargs

    def form_valid(self, form):
        # form.instance.compte.client = self.request.user
        return super().form_valid(form)

class PretCreateView(LoginRequiredMixin, CreateView):
    model = Pret
    form_class = PretForm
    success_url = reverse_lazy('compte_home')
    template_name = "compte/pret_create.html"

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['user'] = self.request.user
        return kwargs

    def form_valid(self, form):
        return super().form_valid(form)
     

class RemboursementCreateView(LoginRequiredMixin, CreateView):
    model = Remboursement
    form_class = RemboursementForm
    success_url = reverse_lazy('compte_home')
    template_name = "compte/remboursement_create.html"

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['user'] = self.request.user
        return kwargs

    def form_valid(self, form):
        return super().form_valid(form)
     
class TransfertCreateView(LoginRequiredMixin, CreateView):
    model = Transfert
    form_class = TransfertForm
    success_url = reverse_lazy('compte_home')
    template_name = "compte/transfert_create.html"

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['user'] = self.request.user
        return kwargs

    def form_valid(self, form):
        return super().form_valid(form)