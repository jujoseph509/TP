from django.urls import path
from django.contrib.auth import views as auth_views

from .views import *


urlpatterns = [
    path('', CompteTemplateView.as_view(), name='compte_home'),
    path('list/', CompteView.as_view(), name='compte_list'),
    path('transaction/create/', TransactionCreateView.as_view(), name='transaction_create'),
    path('compte/create/', CompteCreateView.as_view(), name='compte_create'),
    path('transfert/create/', TransfertCreateView.as_view(), name='transfert_create'),
    path('pret/create/', PretCreateView.as_view(), name='pret_create'),
    path('remboursement/create/', RemboursementCreateView.as_view(), name='remboursement_create'),
    path('gestion-compte/', GestionCompteView.as_view(), name='gestion_compte'),


    path('transfert/list/', TransfertListView.as_view(), name='transfert_list'),
    path('transaction/list/', TransactionListView.as_view(), name='transaction_list'),
    path('pret/list/', PretListView.as_view(), name='pret_list'),
    path('remboursement/list/', RemboursementListView.as_view(), name='remboursement_list'),

    
]