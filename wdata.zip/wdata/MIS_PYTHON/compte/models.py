from django.db import models
from client.models import Client
from django.core.exceptions import ValidationError

from django.core.validators import MinValueValidator

# Create your models here.

TYPE_CHOICES = (
    ('epargne', 'Epargne'),
    ('courant', 'Courant'),
)

ETAT_CHOICES = (
    ('actif', 'Actif'),
    ('inactif', 'Inactif'),
    ('bloque', 'Bloque'),
)

DEVISE_CHOICES = (
    ('gourdes', 'Gourdes'),
    ('dollars', 'Dollars'),
    # ('bloque', 'Bloque'),
)


class Compte(models.Model):
    client = models.ForeignKey(Client, on_delete=models.CASCADE)
    solde = models.DecimalField(max_digits=10, decimal_places=2, validators=[MinValueValidator(1)])
    devise_compte = models.CharField(max_length=7, choices=DEVISE_CHOICES, default='gourdes')
    type_compte = models.CharField(max_length=7, choices=TYPE_CHOICES, default='epargne')
    etat_compte = models.CharField(max_length=7, choices=ETAT_CHOICES, default='actif')

    def __str__(self) -> str:
        return f"{self.client} (Etat: {self.etat_compte} - Type: {self.type_compte} - Devise: {self.devise_compte})"

    def empecher_changer_devise(self):
        if self.pk is not None:
            compte = Compte.objects.get(pk=self.pk)
            return compte.devise_compte != self.devise_compte
        return False

    def crediter(self, montant):
        """Methode permettant d'augmenter le montant d'un compte"""
        # if montant <=0: raise Exception("Montant crediter inferieur a 0")
        self.solde += montant

    def debiter(self, montant):
        """Methode permettant de reduire le solde d'un compte"""
        # if montant > self.solde: raise Exception("Montant le depasse le solde du compte")
        self.solde -= montant

    def is_compte_actif(self):
        return self.etat_compte == 'actif'
    
    def is_compte_bloquer(self):
        return self.etat_compte == 'bloque'
    
    def clean(self):
        if self.solde <= 0:
            raise ValidationError({'solde':"Le solde saisi doit être supérieur à zéro. Veuillez entrer une valeur positive."})

        if self.empecher_changer_devise():
            raise ValidationError("Vous ne pouvez pas changer la devise d'un compte existant")
