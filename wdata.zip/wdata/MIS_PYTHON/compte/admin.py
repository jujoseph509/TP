from django.contrib import admin
from .models import Compte
# Register your models here.

@admin.register(Compte)
class CompteAdmin(admin.ModelAdmin):
    list_display = ['client', 'solde', 'devise_compte', 'type_compte', 'etat_compte']
    list_filter = ('devise_compte',)
