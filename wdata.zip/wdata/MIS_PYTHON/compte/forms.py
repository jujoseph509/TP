from django import forms
from .models import Compte

from client.models import Client


class CompteForm(forms.ModelForm):

    
    def __init__(self, user, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['client'].queryset = Client.objects.filter(email=user.email)
        # self.fields["etat_compte"].widget.attrs["readonly"] = True
        # self.fields["etat_compte"].widget.attrs["disabled"] = True
        # self.fields['etat_compte'].widget.attrs['required'] = False




    class Meta:
        etat_compte = forms.CharField(required=False)
        model = Compte
        fields = ("__all__")
        exclude = ('etat_compte',)