from django.db.models.signals import post_save
from django.dispatch import receiver
from django.db import models
from compte.models import Compte
from decimal import Decimal
from django.db.models import Sum

from django.core.exceptions import ValidationError

# Create your models here.
class Pret(models.Model):
    compte = models.ForeignKey(Compte, on_delete=models.CASCADE, related_name='pret_compte')
    montant_pret = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    taux_interet = models.DecimalField(max_digits=10, decimal_places=2, default=0.055)
    versement_periodique = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    is_rembourser:bool = models.BooleanField(default=False)
    date_pret = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name =("Pret")
        ordering = ['-date_pret']
        verbose_name_plural =("Prets")

    def __str__(self):
        return f"{self.compte.client} (Montant: {self.versement_periodique} - Devise: {self.compte.devise_compte}-{self.is_rembourser})"
    def egal(self):
        return self.total_remboursement() == self.montant_pret

    # data
    def mise_a_jour_remboursement(self):
        if self.total_remboursement() == self.montant_pret:
            self.is_rembourser = True
            self.save()

    def calculer_versement_periodique(self, nombre_versements=4):
        montant_total = self.montant_pret + (self.montant_pret * Decimal(self.taux_interet))
        self.versement_periodique = montant_total / nombre_versements
        self.montant_pret = montant_total

    def save(self, *args, **kwargs):
        if not self.pk:
            self.calculer_versement_periodique()
        super().save(*args, **kwargs)

    def client_a_pret_en_cours(self):
        return Pret.objects.filter(compte__client=self.compte.client, is_rembourser=False).exists()

    def verifier_remboursement_complet(self):
        if self.total_remboursement() == self.montant_pret:
            self.is_rembourser = True
            self.save(update_fields=['is_rembourser'])

    def clean(self) -> None:
        if self.compte.devise_compte == 'dollars':
            raise ValidationError({'compte': "Pour être éligible à un prêt, vous devez avoir un compte en gourdes."})

        if self.compte.solde < 15000:
            raise ValidationError('Pour faire un pret vous devez avoir au minimum 15000 gourdes sur votre compte')

        if self.montant_pret <=0:
            raise ValidationError({'montant': "Le montant saisi doit être supérieur à zéro. Veuillez entrer une valeur positive."})

        if not self.compte.is_compte_actif():
            raise ValidationError("Vous ne pouvez pas effectuer de prêt car le compte n'est pas actif.")

        if self.compte.is_compte_bloquer():
            raise ValidationError("Vous ne pouvez pas effectuer de prêt car le compte est bloquer.")

        if self.pk is None and self.client_a_pret_en_cours():
            raise ValidationError("Ce client a déjà un prêt en cours, vous ne pouvez pas avoir un autre prêt.")
        
    def total_remboursement(self):
        """ somme de tous les remboursements pour ce prêt """
        return self.remboursement_pret.aggregate(total=Sum('montant_remb'))['total'] or Decimal(0)