from django import forms
from .models import Pret
from compte.models import Compte
class PretForm(forms.ModelForm):
    def __init__(self, user, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['compte'].queryset = Compte.objects.filter(client_id=user.pk)
    class Meta:
        model = Pret
        fields = ("__all__")
        exclude = ('taux_interet', 'versement_periodique', 'is_rembourser',)
