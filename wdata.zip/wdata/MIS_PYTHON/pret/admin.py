from django.contrib import admin
from .models import Pret
# Register your models here.
@admin.register(Pret)
class PretAdmin(admin.ModelAdmin):
    list_display = ['compte', 'montant_pret', 'taux_interet', 'versement_periodique', 'date_pret', 'pret_en_cours']

    def pret_en_cours(self, obj):
        return obj.is_rembourser
