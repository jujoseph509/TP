from django.db import models
from compte.models import Compte
from decimal import Decimal
from django.db.models import Sum

from django.core.exceptions import ValidationError

# Create your models here.
class Pret(models.Model):
    compte = models.ForeignKey(Compte, on_delete=models.CASCADE, related_name='pret_compte')
    montant = models.DecimalField(max_digits=10, decimal_places=2)
    taux_interet = models.DecimalField(max_digits=10, decimal_places=2, default=0.055)
    versement_periodique = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    is_rembourser:bool = models.BooleanField(default=False)
    date_pret = models.DateTimeField(auto_now_add=True)

    def montant_rembourse(self):
        """ somme rembourser pour un pret """
        total_rembourse = self.remboursement_pret.aggregate(Sum('montant'))['montant__sum'] or 0
        return total_rembourse
    
    def nombre_remboursements(self):
        """ nombre de remboursements effectués pour un prêt """
        return self.remboursement_pret.count()

    class Meta:
        verbose_name =("Pret")
        verbose_name_plural =("Prets")

    def __str__(self):
        # return f"{self.compte.type_compte} {self.compte.client.nom} {self.compte.devise_compte}"
        return f"{self.compte.client} (Montant: {self.versement_periodique} - Devise: {self.compte.devise_compte})"
        # return f"{self.compte.client} (Montant: {self.montant} - Devise: {self.compte.devise_compte})"


    def is_solde_compte(self):
        """ is solde inferieur a 15000 gourdes """
        return self.compte.solde < 15000

    def is_devise_gourdes(self):
        return self.compte.devise_compte.lower() == 'gourdes'

    def set_montant(self):
        # return self.montant + (self.montant * self.taux_interet)
        self.montant = self.montant + (self.montant * Decimal(self.taux_interet))
        return self.montant

    def set_versement_peridique(self):
        return self.montant / 4
        
    def save(self, *args, **kwargs):
        if self.compte.is_compte_actif() and self.is_devise_gourdes() and self.is_devise_gourdes():
            v = self.set_montant()
            self.versement_periodique = v / 4
            super().save(args, kwargs)

    def clean(self):
        if not self.compte.is_compte_actif():
            raise ValidationError("Vous ne pouvez pas effectué de pret car le compte n'est pas actif.")

        if not self.is_devise_gourdes():
            raise ValidationError({'compte':"Pour être éligible à un prêt, vous devez avoir un compte en gourdes."})

        # if self.is_solde_compte():
        #     raise ValidationError('Pour être éligible à un prêt, vous devez avoir un solde superieur ou egal a 15 000 gourdes.')


