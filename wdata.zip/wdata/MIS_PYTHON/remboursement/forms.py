from django import forms
from .models import Remboursement
from pret.models import Pret
class RemboursementForm(forms.ModelForm):
    def __init__(self, user, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # les pret rembourse n'affiche pas
        self.fields['pret'].queryset = Pret.objects.filter(compte__client=user.pk, is_rembourser=False)

        # self.fields['pret'].queryset = Pret.objects.filter(compte__client=user.pk).filter(is_rembourser=False)
    class Meta:
        model = Remboursement
        fields = ("__all__")
