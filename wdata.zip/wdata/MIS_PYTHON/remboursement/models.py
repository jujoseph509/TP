from django.db import models
from pret.models import Pret
from django.core.exceptions import ValidationError
from django.db.models.signals import post_save
from django.dispatch import receiver

class Remboursement(models.Model):
    pret = models.ForeignKey(Pret, on_delete=models.CASCADE, related_name='remboursement_pret')
    montant_remb = models.DecimalField(max_digits=10, decimal_places=2)
    date_rembour = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        self.montant_remb = self.pret.versement_periodique
        self.effectuer_remboursement()
        self.pret.mise_a_jour_remboursement()

        super().save(*args, **kwargs)

    def effectuer_remboursement(self):
        self.full_clean()
        self.pret.compte.solde -= self.montant_remb
        self.pret.compte.save()
        # if self.pret.total_remboursement() == self.pret.montant:
        #     self.pret.is_rembourser = True
        #     self.pret.save()

    def verification_solde_client(self):
        return self.pret.compte.solde < self.pret.versement_periodique
    
    def clean(self) -> None:
        if not self.pret.compte.is_compte_actif():
            raise ValidationError("Vous ne pouvez pas effectuer de remboursement car le compte n'est pas actif.")

        if self.pret.is_rembourser:
            raise ValidationError("Ce prêt a déjà été remboursé en totalité.")
        
        if self.pret.compte.devise_compte != 'gourdes':
            raise ValidationError("Vous ne pouvez pas effectuer de remboursement.")

        if self.montant_remb < self.pret.versement_periodique:
            raise ValidationError({'montant': f"Le montant doit être égal au versement périodique de {self.pret.versement_periodique} Gourdes"})

        if self.pret.compte.is_compte_bloquer():
            raise ValidationError("Vous ne pouvez pas effectuer de remboursement le compte est bloquer")

        if self.verification_solde_client():
            raise ValidationError("Vous n'avez pas assez de fond pour effectuer ce renboursement.")

    class Meta:
        verbose_name = ("remboursement")
        verbose_name_plural = ("remboursements")
        ordering = ['-date_rembour']

@receiver(post_save, sender=Remboursement)
def update_pret_remboursement(sender, instance, **kwargs):
    pret = instance.pret
    if pret.egal():
        pret.is_rembourser = True
        pret.save()