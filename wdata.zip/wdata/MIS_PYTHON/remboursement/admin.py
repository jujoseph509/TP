from django.contrib import admin
from .models import Remboursement
# Register your models here.
@admin.register(Remboursement)
class RemboursementAdmin(admin.ModelAdmin):
    list_display = ['pret', 'montant_remb', 'date_rembour']
