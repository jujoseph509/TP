from django.db import models
from pret.models import Pret
from django.core.exceptions import ValidationError

# Create your models here.
class Remboursement(models.Model):
    pret = models.ForeignKey(Pret, on_delete=models.CASCADE, related_name='remboursement_pret')
    montant = models.DecimalField(max_digits=10, decimal_places=2)
    date_remboursement = models.DateTimeField(auto_now_add=True)
    

    class Meta:
        verbose_name = ("remboursement")
        verbose_name_plural = ("remboursements")

    # def is_montant(self):
    #     return self.montant >= self.pret.versement_periodique

    def save(self, *args, **kwargs):
        if self.pret:
            print(self.pret.montant_rembourse(), "*"*50)
            super().save(*args, **kwargs)

    def is_montant_v(self):
        return self.montant < self.pret.versement_periodique


    
    def clean(self):
        # if not self.is_montant():
            # raise ValidationError({'montant': f"Le montant que vous avez saisi est inférieur à la somme requise pour le versement, qui est de {self.pret.versement_periodique} {self.pret.compte.devise_compte.capitalize()}"})


        if self.is_montant_v():
            if self.montant < self.pret.versement_periodique:
                raise ValidationError({'montant': f"Le montant saisi diffère du montant prévu de 123$ {self.pret.versement_periodique} "})

        if self.pret is not None and self.montant < self.pret.versement_periodique:
            raise ValidationError({'montant': f"Le montant saisi diffère du montant prévu de {self.pret.versement_periodique}$"})

        # if self.get_sum_remboursement() == self.pret.montant:
        #     raise ValidationError("Le montant que vous avez est suffisant")


