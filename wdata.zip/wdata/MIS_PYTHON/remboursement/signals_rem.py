# from .models import Remboursement


# @receiver(post_save, sender=Remboursement)
# def update_pret_remboursement(sender, instance, **kwargs):
#     pret = instance.pret
#     if pret.egal():
#         pret.is_rembourser = True
#         pret.save()