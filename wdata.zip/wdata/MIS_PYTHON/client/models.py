from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils.translation import gettext_lazy as _
# Create your models here.
SEXE_CHOICES = (
    ('masculin', 'Masculin'),
    ('feminin', 'Feminin')
)

class Client(AbstractUser):
    nom = models.CharField(_('nom'), max_length=25, null=True, blank=True)
    username = None
    prenom = models.CharField(_('prenom'), max_length=25, null=True, blank=True)
    sexe = models.CharField(max_length=8, choices=SEXE_CHOICES, default='masculin')
    email = models.EmailField(_('email'), max_length=255,blank=False, unique=True)
    adresse = models.CharField(_('adresse'), max_length=25, null=True, blank=True)
    telephone = models.CharField(max_length=25, null=True, blank=True)
    profile = models.ImageField(upload_to='profile/img/%Y/%m/%d/', default="../static/img/img_login.svg", blank=True)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['nom', 'prenom', 'username']
    # REQUIRED_FIELDS.remove('username')


    class Meta:
        verbose_name = ("Client")
        verbose_name_plural = ("Clients")

    def __str__(self):
        return f"{self.email}"
    
    # def a_un_pret_en_cours(self):
    #     return self.compte_set.filter(pret_compte__is_rembourser=False, pk=self.pk).exists()

    # def a_un_pret_en_cours(self):
    #     pret_count = Pret.objects.filter(compte__client=self, is_rembourser=False).count()
    #     return pret_count > 0
    # def remove_username_field(self):
    #     if 'username' in self.REQUIRED_FIELDS:
    #         self.REQUIRED_FIELDS.remove('username')
    
""" Dans cet exemple, la méthode a_un_pret_en_cours utilise la relation inverse 
compte_set pour récupérer tous les comptes associés à ce client, puis utilise 
la relation pret_compte pour filtrer les prêts non remboursés associés à ces comptes. 
Enfin, la méthode exists()  """
