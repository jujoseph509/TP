from django.forms import forms
from django.contrib.auth.forms import UserChangeForm, UserCreationForm
from django.contrib.auth import get_user_model


class RegisterForm(UserCreationForm):
    class Meta:
        model = get_user_model()
        fields = ("email", "nom", "prenom", "sexe", "telephone", "adresse")

        # help_texts = {
        #     "username": None,
        #     "profile_img": None,
        #     "password1": None,
        #     "password2": None
        # }
        
    def __init__(self, *args, **kwargs):
        super(RegisterForm, self).__init__(*args, **kwargs)
        # del self.fields['password2']
        self.fields['password1'].help_text = None
        self.fields['password2'].help_text = None
        # self.fields['username'].help_text = None

"""         labels = {
            "password": ''
        } """


class UpadteForm(UserChangeForm):
    class Meta:
        model = get_user_model()
        fields = ( "email", "nom", "prenom", "sexe", "adresse", "telephone", "profile")
        help_texts = {
            "username": None,
            "profile": None
        }