from django.urls import path
from django.contrib.auth import views as auth_views

from .views import *


urlpatterns = [
    # """ auth """
    path('login/', auth_views.LoginView.as_view(template_name='accounts/login.html'), name='login'),
    path('register/', RegisterView.as_view(template_name='accounts/register.html'), name='register'),
    path('logout/', auth_views.LogoutView.as_view(next_page='login'), name='logout'),

    # """ dashboard """
    path('dashboard/', DashboardTemplateView.as_view(), name='dashboard_home'),

    # """ profile """
    path('profile/update/', ClientUpdateView.as_view(), name='profile_update'),

    # """ password """
    path('password/change/', auth_views.PasswordChangeView.as_view(template_name='accounts/password/password_change.html',success_url='/'),name='change_password'),
    path('password/reset/', auth_views.PasswordResetView.as_view(template_name='accounts/password/password_reset.html') ,name='password_reset'),
    path('password/reset/done/',auth_views.PasswordResetDoneView.as_view(template_name='accounts/password/password_reset_done.html'),name='password_reset_done'),
    path('password/reset/confirm/<uidb64>/<token>/',auth_views.PasswordResetConfirmView.as_view(template_name='accounts/password/password_reset_confirm.html'),name='password_reset_confirm'),
    path('password/reset/complete/',auth_views.PasswordResetCompleteView.as_view(template_name='accounts/password/password_reset_complete.html'),name='password_reset_complete'),
]
