
from django.shortcuts import render, HttpResponseRedirect
# Create your views here.
from .models import Client
from django.views.generic import TemplateView, CreateView
from django.urls import reverse_lazy, reverse
from .forms import UpadteForm, RegisterForm
from django.contrib.auth.mixins import LoginRequiredMixin

class RegisterView(CreateView):
    model = Client
    form_class = RegisterForm
    success_url = reverse_lazy('dashboard_home')
    template_name = "accounts/register.html"

    def form_valid(self, form):
        return super().form_valid(form)

class DashboardTemplateView(LoginRequiredMixin, TemplateView):
    template_name = 'accounts/dashboard/dashboard.html'
    model = Client

class ClientUpdateView(LoginRequiredMixin, TemplateView):
    model = Client
    form_class = UpadteForm
    template_name = 'accounts/profile/profile_update.html' 

    def post(self, request):
        post_data = request.POST or None
        form = UpadteForm(post_data,   instance=request.user)
        if  form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse_lazy('dashboard_home'))
        context = self.get_context_data(form=form)
        return self.render_to_response(context) 
               
    def get(self, request, *args, **kwargs):
        return self.post(request, *args, **kwargs)